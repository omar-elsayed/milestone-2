package tcp2;
import java.io.*; 
import java.net.*; 

class TCPServer { 

  public static void main(String argv[]) throws Exception 
    { 
      String clientSentence; 
      String capitalizedSentence; 


    boolean f= true;
      String text2="";

      ServerSocket welcomeSocket = new ServerSocket(1596); 
      String text= "";
      Socket connectionSocket = welcomeSocket.accept(); 
      while(true) { 
  
          

           BufferedReader inFromClient = 
              new BufferedReader(new
              InputStreamReader(connectionSocket.getInputStream())); 
           
           
           text= inFromClient.readLine();
           System.out.println("FROM CLIENT"+text);
           BufferedReader inFromServer = 
        	        new BufferedReader(new InputStreamReader(System.in)); 
           text2=inFromServer.readLine();
           //text2="Connection Denied";
           DataOutputStream  outToClient = 
                   new DataOutputStream(connectionSocket.getOutputStream()); 

           outToClient.writeBytes(text2+'\n'); 
          // f=true;
              } 
      
          }
  
  
      } 
