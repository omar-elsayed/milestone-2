package tcp2;


import java.io.*; 
import java.net.*; 
class TCPClient{ 

    public static void main(String argv[]) throws Exception 
    { 
        String sentence; 
        String modifiedSentence;
        Socket clientSocket = null;

       
        BufferedReader inFromUser = 
          new BufferedReader(new InputStreamReader(System.in)); 
        sentence = inFromUser.readLine(); 
while(sentence.equals("connect")) {
      
        clientSocket = new Socket("localhost", 1596); 
        BufferedReader inFromUser2 = 
                new BufferedReader(new InputStreamReader(System.in)); 
              String sentence2 = inFromUser.readLine(); 

        DataOutputStream outToServer = 
          new DataOutputStream(clientSocket.getOutputStream());
        outToServer.writeBytes(sentence2 + '\n'); 

        BufferedReader inFromServer = 
                new BufferedReader(new
                InputStreamReader(clientSocket.getInputStream())); 

              

              modifiedSentence = inFromServer.readLine(); 

              System.out.println("FROM SERVER: " + modifiedSentence); 

              
                         
          }  clientSocket.close();}
      } 
